# -*- coding: utf-8 -*-
"""
engine.py — 부품 이미지 매칭 엔진 (Photo_Val.py 의 SIFT 로직 이식)

  · parse_workbook : 엑셀에서 (셀 삽입 이미지 + 서비스 코드) 추출
  · get_sift_features / match_features : SIFT + RANSAC inlier 매칭 (원본과 동일)
  · remove_bg_white : rembg 배경 제거 + 흰 배경 합성 → JPG
"""
import glob
import io
import os
import threading

import cv2
import numpy as np
import openpyxl
from openpyxl.utils import column_index_from_string
from openpyxl_image_loader import SheetImageLoader
from PIL import Image

_sift = cv2.SIFT_create()

# ---------------------------------------------------------------- 엑셀 파싱

def parse_workbook(xlsx_bytes: bytes, img_col: str = "D", code_col: str = "E", start_row: int = 4):
    """엑셀 바이트 → [{sheet, rows:[{row, code, image(PIL)}]}]  (Photo_Val.py 와 동일 규칙)"""
    wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), data_only=True)
    img_idx = column_index_from_string(img_col.upper())
    out = []
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        try:
            loader = SheetImageLoader(ws)
        except Exception:
            continue

        # 코드가 있는 마지막 행 (원본 last_row 로직)
        last_row = ws.max_row
        while last_row >= 1 and not ws[f"{code_col}{last_row}"].value:
            last_row -= 1

        rows = []
        for row in range(start_row, last_row + 1):
            raw = ws[f"{code_col}{row}"].value
            if raw is None:
                continue
            code = str(raw).strip()
            if not code or code == "None":
                continue
            cell = f"{img_col.upper()}{row}"
            try:
                if not loader.image_in(cell):
                    continue
                pil = loader.get(cell)
            except Exception:
                continue
            rows.append({"row": row, "code": code, "image": pil})
        if rows:
            out.append({"sheet": sheet_name, "rows": rows})
    return out


# ---------------------------------------------------------------- SIFT 매칭 (Photo_Val.py 그대로)

def get_sift_features(pil_img: Image.Image):
    try:
        if pil_img.mode == "RGBA":
            white = Image.new("RGB", pil_img.size, (255, 255, 255))
            white.paste(pil_img, mask=pil_img.split()[3])
            pil_img = white
        else:
            pil_img = pil_img.convert("RGB")

        img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        h, w = gray.shape
        if max(h, w) > 512:
            s = 512.0 / max(h, w)
            gray = cv2.resize(gray, (int(w * s), int(h * s)))

        kp, des = _sift.detectAndCompute(gray, None)
        return kp, des
    except Exception:
        return None, None


def match_features(kp1, des1, kp2, des2) -> int:
    """KNN ratio test(0.7) → good>=10 → RANSAC homography inlier 수 (원본과 동일)"""
    if des1 is None or des2 is None or len(des1) < 2 or len(des2) < 2:
        return 0
    try:
        bf = cv2.BFMatcher()
        matches = bf.knnMatch(des1, des2, k=2)
        good = [m for pair in matches if len(pair) == 2 for m, n in [pair] if m.distance < 0.7 * n.distance]
        if len(good) >= 10:
            src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
            dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
            _, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
            if mask is not None:
                return int(np.sum(mask))
        return 0
    except Exception:
        return 0


# ---------------------------------------------------------------- 배경 제거 → JPG

_rembg_session = None
_model_dir = None  # u2net.onnx 가 있는 폴더 (1회 탐색 후 캐시)


def _log(cb, msg, level="info"):
    """세부 로그 콜백(있으면) 호출. 콜백은 (msg, level) 시그니처."""
    if cb:
        try:
            cb(msg, level)
        except Exception:
            pass


def _call_with_timeout(fn, timeout):
    """fn() 을 별도 스레드로 실행하고 timeout 초 안에 안 끝나면 TimeoutError.
    (모델 다운로드가 사내망 차단으로 무한 대기하는 것을 방지)"""
    box = {}

    def run():
        try:
            box["v"] = fn()
        except Exception as e:  # noqa: BLE001
            box["e"] = e

    t = threading.Thread(target=run, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        raise TimeoutError(f"{timeout}초 안에 끝나지 않았습니다")
    if "e" in box:
        raise box["e"]
    return box.get("v")


def find_u2net_model(log=None):
    """u2net.onnx 를 서버 여러 위치에서 찾아 U2NET_HOME 을 지정한다.
    찾으면 폴더 경로 반환, 못 찾으면 None (다운로드는 사내망에서 막히므로 시도 안 함)."""
    global _model_dir
    if _model_dir:
        return _model_dir

    candidates = []
    env = os.environ.get("U2NET_HOME")
    if env:
        candidates.append(env)
    candidates += [
        os.path.join(os.path.expanduser("~"), ".u2net"),
        r"C:\ServerBox\models",
        r"C:\Windows\System32\config\systemprofile\.u2net",
    ]
    candidates += glob.glob(r"C:\Users\*\.u2net")

    seen = set()
    for d in candidates:
        if not d or d in seen:
            continue
        seen.add(d)
        p = os.path.join(d, "u2net.onnx")
        _log(log, f"모델 탐색: {p}", "dim")
        if os.path.isfile(p):
            os.environ["U2NET_HOME"] = d
            _model_dir = d
            mb = os.path.getsize(p) // (1024 * 1024)
            _log(log, f"✔ u2net 모델 발견 → {p} ({mb}MB), U2NET_HOME 지정", "ok")
            return d

    _log(log, "✖ u2net.onnx 를 서버 어디에서도 찾지 못함 (관리자에게 모델 설치 요청 필요)", "bad")
    return None


def remove_bg_white(pil_img: Image.Image, use_bg: bool = True, quality: int = 92, log=None) -> bytes:
    """배경 제거(옵션) 후 흰 배경 합성 → JPG 바이트 (원본 파이프라인과 동일, 저장만 jpg)"""
    global _rembg_session
    img = pil_img
    if max(img.size) > 1024:  # rembg 메모리 보호 (원본과 동일)
        img = img.copy()
        img.thumbnail((1024, 1024), Image.Resampling.LANCZOS)

    if use_bg:
        model_dir = find_u2net_model(log)
        if model_dir is None:
            raise RuntimeError("배경 제거 모델(u2net.onnx)이 서버에 없습니다. "
                               "관리자에게 모델 설치를 요청하거나 'AI 배경 제거 사용'을 꺼 주세요.")
        from rembg import remove, new_session
        if _rembg_session is None:
            _log(log, "rembg 세션 생성 중… (최초 1회 모델 로딩, 최대 90초 대기)", "info")
            _rembg_session = _call_with_timeout(lambda: new_session("u2net"), 90)
            _log(log, "✔ rembg 세션 준비 완료 (이후 장부터는 빠름)", "ok")
        img = remove(img, session=_rembg_session)

    white = Image.new("RGB", img.size, (255, 255, 255))
    if img.mode == "RGBA":
        white.paste(img, mask=img.split()[3])
    else:
        white.paste(img)

    buf = io.BytesIO()
    white.save(buf, "JPEG", quality=quality)
    return buf.getvalue()


# ---------------------------------------------------------------- 유틸

def pil_to_jpeg_b64(pil_img: Image.Image, max_px: int = 240) -> str:
    """표시용 썸네일 base64 (프런트 카드용)"""
    import base64
    img = pil_img.convert("RGB")
    img.thumbnail((max_px, max_px), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=80)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
