# 서버 PC에서 "관리자 권한 PowerShell"로 실행하세요.
#   예)  powershell -ExecutionPolicy Bypass -File .\적용.ps1
# 이 스크립트가 있는 폴더의 main.py / app.js / index.html 을
# C:\ServerBox\apps\parts 에 복사하고 서비스를 재시작합니다.

$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = "C:\ServerBox\apps\parts"

if (-not (Test-Path $dst)) { Write-Host "대상 폴더가 없습니다: $dst" -ForegroundColor Red; exit 1 }

# 백업
$bak = Join-Path $dst ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force $bak | Out-Null
Copy-Item (Join-Path $dst "main.py") $bak -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "static\app.js") $bak -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "static\index.html") $bak -ErrorAction SilentlyContinue

# 복사 (바이트 그대로 — 인코딩 변환 없음)
Copy-Item (Join-Path $src "main.py")    (Join-Path $dst "main.py")    -Force
Copy-Item (Join-Path $src "app.js")     (Join-Path $dst "static\app.js")     -Force
Copy-Item (Join-Path $src "index.html") (Join-Path $dst "static\index.html") -Force
Write-Host "파일 복사 완료 (백업: $bak)" -ForegroundColor Green

# 문법 확인
& "C:\ServerBox\venvs\parts\Scripts\python.exe" -c "import sys; sys.path.insert(0,'C:/ServerBox/apps/parts'); import main; print('IMPORT_OK')"
if ($LASTEXITCODE -ne 0) { Write-Host "main.py 임포트 실패 — 서비스 재시작을 중단합니다." -ForegroundColor Red; exit 1 }

# 서비스 재시작
Restart-Service ServerBox-Parts
Start-Sleep -Seconds 3
Get-Service ServerBox-Parts | Format-List Name, Status
Write-Host "완료! 브라우저에서 접속해 'AI 유사도 매칭' 체크박스가 보이는지 확인하세요." -ForegroundColor Green
