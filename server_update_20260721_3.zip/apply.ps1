# 서버 PC에서 "관리자 권한 PowerShell"로 실행하세요.
#   예)  powershell -ExecutionPolicy Bypass -File .\apply.ps1
# 이 폴더의 소스 5개(main.py, engine.py, app.js, index.html, styles.css)를
# C:\ServerBox\apps\parts 에 반영하고, 문법 확인 후 서비스를 재시작합니다.
# 이번 업데이트: 실행 로그 2단(메인/세부진단) + u2net 모델 자동 탐색·무한대기 방지.

$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = "C:\ServerBox\apps\parts"
if (-not (Test-Path $dst)) { Write-Host "대상 폴더가 없습니다: $dst" -ForegroundColor Red; exit 1 }

# 백업
$bak = Join-Path $dst ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force $bak | Out-Null
New-Item -ItemType Directory -Force (Join-Path $bak "static") | Out-Null
Copy-Item (Join-Path $dst "main.py")   $bak -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "engine.py") $bak -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "static\app.js")     (Join-Path $bak "static") -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "static\index.html") (Join-Path $bak "static") -ErrorAction SilentlyContinue
Copy-Item (Join-Path $dst "static\styles.css") (Join-Path $bak "static") -ErrorAction SilentlyContinue

# 복사 (바이트 그대로 — 인코딩 변환 없음)
Copy-Item (Join-Path $src "main.py")     (Join-Path $dst "main.py")   -Force
Copy-Item (Join-Path $src "engine.py")   (Join-Path $dst "engine.py") -Force
Copy-Item (Join-Path $src "app.js")      (Join-Path $dst "static\app.js")     -Force
Copy-Item (Join-Path $src "index.html")  (Join-Path $dst "static\index.html") -Force
Copy-Item (Join-Path $src "styles.css")  (Join-Path $dst "static\styles.css") -Force
Write-Host "파일 5개 복사 완료 (백업: $bak)" -ForegroundColor Green

# 문법 확인
& "C:\ServerBox\venvs\parts\Scripts\python.exe" -c "import sys; sys.path.insert(0,'C:/ServerBox/apps/parts'); import main; print('IMPORT_OK')"
if ($LASTEXITCODE -ne 0) { Write-Host "임포트 실패 — 서비스 재시작 중단." -ForegroundColor Red; exit 1 }

# 서비스 재시작
Stop-Service ServerBox-Parts -Force -ErrorAction SilentlyContinue
Start-Service ServerBox-Parts
Start-Sleep -Seconds 3
Get-Service ServerBox-Parts | Format-List Name, Status
Write-Host "완료! 브라우저 Ctrl+F5 후 배경 제거를 다시 시도하고, 우측 '세부 실행·진단' 로그를 확인하세요." -ForegroundColor Green
